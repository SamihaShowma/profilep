#  Bootstrap 5 Side Navigation Menu
 Side Navigation Menu Using Bootstrap 5 & jQuery
### Preview

<a target="_blank" href="https://www.youtube.com/watch?v=_RlexKmLyCk&list=PLkyGuIcLcmx0G69uguLOK1I0erp_Y_4bX&index=2&t=0s">TUTORIAL VIDEO</a>

<a target="_blank" href="https://rupomsoft.github.io/Bootstrap-5-Side-Navigation-Menu">LIVE DEMO</a>

<img width="100%" src="https://github.com/rupomsoft/Bootstrap-5-Side-Navigation-Menu/blob/master/Preview.gif"/>

### Licensing
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
